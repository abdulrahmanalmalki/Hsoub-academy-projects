require("./config/indexNormal");

require("./config/indexTimed");

require("./config/indexImaged");
