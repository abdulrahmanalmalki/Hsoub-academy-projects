import Colors from "./colors";
import Strings from "./strings";
import Axios from "./axios";
import Moment from "./moment";
import Urls from "./urls";
import Auth from "./auth";

export {
  Colors, Strings, Axios, Moment, Urls, Auth
}