const colors = {
  GRAY: "#616571",
  BLACK: "#000",
  WHITE: "#FFF",
  LOADING_CIRCLE: "#20C997",
  INCOMING_MESSAGE: "#dcf8c6",
  OUTCOMING_MESSAGE: "#fff",
};

export default colors;