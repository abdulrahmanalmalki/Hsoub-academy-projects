import moment from 'moment/min/moment-with-locales';

moment.locale('ar');

export default moment;