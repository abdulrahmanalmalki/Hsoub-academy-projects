import React from 'react';

const NotFound = props => {
  return(
    <h3>هذه الصفحة غير موجودة</h3>
  );
}

export default NotFound;