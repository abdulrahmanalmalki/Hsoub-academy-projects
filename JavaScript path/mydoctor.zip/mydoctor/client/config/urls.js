export const API_URL = 'http://localhost:4000';
export const SIGNUP_URL = "/account/signup";
export const SIGNIN_URL = "/account/login";
export const PROFILE_URL = "/account/profile";
export const DELETE_PROFILE_URL = "/account/delete-profile";
export const DOCTORS_URL = "/doctors";
export const UPDATE_PROFILE_URL = "/account/update-profile";